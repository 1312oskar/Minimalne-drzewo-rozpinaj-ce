import java.util.List;


public class Main {
    public static void main(String[] args) {
        int V = 4;
        Graph graph = new Graph(V);
        graph.addEdge(0, 1, 10);
        graph.addEdge(0, 2, 6);
        graph.addEdge(0, 3, 5);
        graph.addEdge(1, 3, 15);
        graph.addEdge(2, 3, 4);

        System.out.println("Minimalne drzewo rozpinające (Kruskal): ");
        List<Edge> kruskalMST = graph.kruskalMST();
        for (Edge edge : kruskalMST) {
            System.out.println(edge.source + " - " + edge.destination + ": " + edge.weight);
        }

        System.out.println("\nMinimalne drzewo rozpinające (Prima): ");
        List<Edge> primMST = graph.primMST();
        for (Edge edge : primMST) {
            System.out.println(edge.source + " - " + edge.destination + ": " + edge.weight);
        }
    }
}
