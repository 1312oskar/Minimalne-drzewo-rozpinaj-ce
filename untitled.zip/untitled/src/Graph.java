import java.util.*;

public class Graph {
    private int V; // Liczba wierzchołków
    private List<Edge> edges; // Lista krawędzi

    public Graph(int V) {
        this.V = V;
        edges = new ArrayList<>();
    }

    // Dodawanie krawędzi do grafu
    public void addEdge(int source, int destination, int weight) {
        Edge edge = new Edge(source, destination, weight);
        edges.add(edge);
    }

    // Metoda Kruskala do wyznaczania minimalnego drzewa rozpinającego
    public List<Edge> kruskalMST() {
        List<Edge> mst = new ArrayList<>();

        // Sortowanie krawędzi według wag
        Collections.sort(edges);

        int[] parent = new int[V];
        for (int i = 0; i < V; i++) {
            parent[i] = i;
        }

        int edgeCount = 0;
        int index = 0;
        while (edgeCount < V - 1) {
            Edge nextEdge = edges.get(index++);
            int x = find(parent, nextEdge.source);
            int y = find(parent, nextEdge.destination);

            if (x != y) {
                mst.add(nextEdge);
                union(parent, x, y);
                edgeCount++;
            }
        }
        return mst;
    }

    private int find(int[] parent, int i) {
        if (parent[i] != i) {
            parent[i] = find(parent, parent[i]);
        }
        return parent[i];
    }

    private void union(int[] parent, int x, int y) {
        int xRoot = find(parent, x);
        int yRoot = find(parent, y);
        parent[xRoot] = yRoot;
    }

    // Metoda Prima do wyznaczania minimalnego drzewa rozpinającego
    public List<Edge> primMST() {
        List<Edge> mst = new ArrayList<>();

        boolean[] inMST = new boolean[V];
        int[] key = new int[V];
        Arrays.fill(key, Integer.MAX_VALUE);

        PriorityQueue<Edge> pq = new PriorityQueue<>(V, Comparator.comparingInt(edge -> edge.weight));
        key[0] = 0;
        pq.offer(new Edge(-1, 0, 0));

        while (!pq.isEmpty()) {
            Edge minEdge = pq.poll();
            int u = minEdge.destination;

            if (inMST[u])
                continue;

            inMST[u] = true;
            mst.add(minEdge);

            for (Edge e : edges) {
                if (e.source == u && !inMST[e.destination] && e.weight < key[e.destination]) {
                    key[e.destination] = e.weight;
                    pq.offer(new Edge(u, e.destination, e.weight));
                }
            }
        }
        return mst;
    }

    public static void main(String[] args) {
        int V = 4;
        Graph graph = new Graph(V);
        graph.addEdge(0, 1, 10);
        graph.addEdge(0, 2, 6);
        graph.addEdge(0, 3, 5);
        graph.addEdge(1, 3, 15);
        graph.addEdge(2, 3, 4);

        System.out.println("Minimalne drzewo rozpinające (Kruskal): ");
        List<Edge> kruskalMST = graph.kruskalMST();
        for (Edge edge : kruskalMST) {
            System.out.println(edge.source + " - " + edge.destination + ": " + edge.weight);
        }

        System.out.println("\nMinimalne drzewo rozpinające (Prima): ");
        List<Edge> primMST = graph.primMST();
        for (Edge edge : primMST) {
            System.out.println(edge.source + " - " + edge.destination + ": " + edge.weight);
        }
    }
}
